import{a as t}from"../chunks/entry.DocAWn_c.js";export{t as start};
